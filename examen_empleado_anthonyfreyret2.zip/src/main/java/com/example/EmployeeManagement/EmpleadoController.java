
package com.example.EmployeeManagement;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;

@Controller
@RequestMapping("/empleados")
public class EmpleadoController {

    @Autowired
    private EmpleadoService empleadoService;

    // Listar todos los empleados
    @GetMapping
    public String listarEmpleados(Model model) {
        model.addAttribute("empleados", empleadoService.listarTodos());
        model.addAttribute("areas", empleadoService.listarAreas());
        return "empleados"; // Thymeleaf view
    }

    // Buscar empleado por DNI
    @GetMapping("/buscar")
    public String buscarEmpleado(@RequestParam("dni") String dni, Model model) {
        Empleado empleado = empleadoService.buscarPorDni(dni);
        model.addAttribute("empleados", Arrays.asList(empleado)); // Usar lista para mantener el mismo diseño
        model.addAttribute("areas", empleadoService.listarAreas());
        return "empleados"; // Thymeleaf view
    }

    // Ver detalles de un empleado específico
    @GetMapping("/{dni}")
    public String verEmpleado(@PathVariable("dni") String dni, Model model) {
        Empleado empleado = empleadoService.buscarPorDni(dni);
        model.addAttribute("empleado", empleado);
        model.addAttribute("areas", empleadoService.listarAreas());
        return "detalleEmpleado"; // Cambia el nombre si necesitas una vista específica
    }

    // Crear o guardar un empleado
    @PostMapping("/guardar")
    public String guardarEmpleado(Empleado empleado) {
        empleadoService.crearEmpleado(empleado);
        return "redirect:/empleados"; // Redirige a la lista de empleados después de guardar
    }

    // Editar empleado
    @GetMapping("/editar/{dni}")
    public String editarEmpleado(@PathVariable("dni") String dni, Model model) {
        Empleado empleado = empleadoService.buscarPorDni(dni);
        model.addAttribute("empleado", empleado);
        model.addAttribute("areas", empleadoService.listarAreas());
        return "empleados"; // Thymeleaf view
    }

    // Eliminar empleado
    @GetMapping("/eliminar/{dni}")
    public String eliminarEmpleado(@PathVariable("dni") String dni) {
        empleadoService.eliminarEmpleado(dni);
        return "redirect:/empleados"; // Redirige a la lista de empleados después de eliminar
    }
}
