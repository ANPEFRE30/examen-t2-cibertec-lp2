
package com.example.EmployeeManagement;

import jakarta.persistence.*;
import java.util.Date;

@Entity
@Table(name = "tb_empleado")
public class Empleado {

    @Id
    @Column(name = "dni_empleado", nullable = false)
    private String dniEmpleado;

    @Column(name = "nombre_empleado")
    private String nombreEmpleado;

    @Column(name = "apellido_empleado")
    private String apellidoEmpleado;

    @Column(name = "fecha_nacimiento")
    private Date fechaNacimiento;

    @Column(name = "direccion")
    private String direccion;

    @Column(name = "correo")
    private String correo;

    @ManyToOne
    @JoinColumn(name = "area_id")
    private Area area;

    // Getters and Setters
}
