
package com.example.EmployeeManagement;

import jakarta.persistence.*;
import java.util.List;

@Entity
@Table(name = "tb_area")
public class Area {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "area_id")
    private Integer areaId;

    @Column(name = "nombre_area")
    private String nombreArea;

    // Getters and Setters
}
